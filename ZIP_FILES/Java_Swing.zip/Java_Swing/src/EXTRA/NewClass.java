
package EXTRA;

import javax.swing.JOptionPane;

public class NewClass 
{
    
    public static void main(String[] args) 
    {
        
        JOptionPane.showMessageDialog(null, "I LOVE YOU\n Is it OK With YOU?", "Caution",JOptionPane.ERROR_MESSAGE);
        
        
    }
    
}
