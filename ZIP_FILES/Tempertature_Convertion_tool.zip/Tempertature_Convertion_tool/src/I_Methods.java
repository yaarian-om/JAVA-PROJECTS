
public interface I_Methods {
    public double celciusToFarenheit(double c);
    public double celciusToKelvin(double c);
    public double farenheitToCelcius(double f);
    public double kelvinToCelcius(double k);
    public double farenheitToKelvin(double f);
    public double kelvinToFarenheit(double k);
}
