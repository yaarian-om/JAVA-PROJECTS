
public class CGPA 
{
    
    public void cgCount(float d)
    {
        if(d>=90)
        {
            System.out.println("Grade = A+");
        }
        else if(d>=85)
        {
            System.out.println("Grade = A");
        }
        else if(d>=80)
        {
            System.out.println("Grade = B+");
        }
        else if(d>=75)
        {
            System.out.println("Grade = B");
        }
        else if(d>=70)
        {
            System.out.println("Grade = C+");
        }
        else if(d>=65)
        {
            System.out.println("Grade = C");
        }
        else if(d>=60)
        {
            System.out.println("Grade = D+");
        }
        else if(d>=50)
        {
            System.out.println("Grade = D");
        }
        else
        {
            System.out.println("Grade = Fail");
        }
        
        
        
        
        
    }
    
    
    
    
    
    
}
