
import java.util.Scanner;

class ShowDetails
{
	
	
	public ShowDetails()
	{
		System.out.println("Name = Sudipta Kumar Das");
		System.out.println("ID = 20-43658-2");
		System.out.println("CGPA = 3.90");
		System.out.println("Department = CSE");
		//System.out.println("AIUB");
		
		
	}
	

}