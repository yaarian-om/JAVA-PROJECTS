
public class VowelChecking 
{
    
    public void volCheck(char $)
    {
       if($== 'a'|| $== 'e' || $== 'i'|| $== 'o'|| $== 'u' || $== 'A'|| $== 'E' || $== 'I'|| $== 'O'|| $== 'U')
       {
           System.out.println($+" is a Vowel");
       }
       else
       {
           System.out.println($+" is a Consonant");
       }
    }
	
}
  