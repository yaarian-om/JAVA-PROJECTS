package pkg1;

public interface IPerson { // implementing Interface it  means full abstraction

    void setName(String name); // Abstract method
    String getName(); // Abstract method

}
