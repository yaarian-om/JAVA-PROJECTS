1) Unzip the folder
2) Open The folder Called Java Learning
3) Goto Dist folder
4) Double click & Open java Learning.jar
5)  Enjoy !!!!
