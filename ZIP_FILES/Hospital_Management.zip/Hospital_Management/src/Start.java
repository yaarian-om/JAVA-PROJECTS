public class Start extends Utility {

	public void main() {
		// TODO - implement Start.main
		throw new UnsupportedOperationException();
	}

}